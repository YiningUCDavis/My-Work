void
move_cars(int *g, int *length, int *car_type, int *cor, int *position)//cor:column or row, depending on the type of car moved
{
    int i;
    int j = 0;
    int len = *length;
    int flag[10000] = {0};
    for(i = 0; i< len; i++)
    {
        if(g[i] == *car_type && flag[i] == 0)
        {
            if(g[(i + *cor) % len] == 3)
            {
                g[(i + *cor) % len] = *car_type;
                flag[(i + *cor) % len] = 1;
                position[j] = i + 1;
                j++;
                g[i] = 3;
            }
        }
        
    }
    
    
}
