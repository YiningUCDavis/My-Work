###################################### generate the matrix
createBMLGrid = function(row =5, column = 5, red = 6, blue = 6){
  status_b <<- NULL
  status_r <<- NULL
  colors = sample(c(rep("blue", blue), rep("red", red), rep("white", row * column - red - blue)))
  numbers = c(1, 2, 3)[factor(colors)]## red = 2, blue = 1, white = 3
  g1 = matrix(colors, nrow = row, ncol = column)
  class(g1) = c("BML", "matrix")
  g2 = matrix(numbers, nrow = row, ncol = column)
  class(g2) = c("BML", "matrix")
  color = max(red, blue)
  list(g1, g2, row, column, color)
}

#############################S3 for plot
plot.BML = function(g, row = 5, column = 5){
  d = g
  d = matrix(as.integer(factor(d)), row, column)
  image(t(d[ncol(d):1, ]), col = c("blue", "red", "white"), axes = FALSE)
  ##blue=1, red=1, white=3 ## the image is horizontally opposite
  box()
}
# plot(grid, 5, 5)
#####################################find the position of red and blue cars
check_color=function(g){
  g = as.matrix(g)
  Rred = row(g)[g == "red"]
  Cred = col(g)[g == "red"]
  #RED = data.frame(Rred, Cred)
  RED = cbind(Rred, Cred)
  
  Rblue = row(g)[g == "blue"]
  Cblue = col(g)[g == "blue"]
  #BLUE = data.frame(Rblue, Cblue) ## remove the data.frame to speed up
  BLUE = cbind(Rblue, Cblue)
  list(BLUE, RED)
}

#########################################get the current position matrix of blue or red cars
position_current = function(g, i){## i = 1 -> blue; i = 2 -> red
  position = check_color(g)[[i]]
  position = as.matrix(position) ## remove the data.frame to speed up
  position
}

##################################################################### calculate the next position of blue cars
next_blue_car = function(Blue, row){
  blue_try = Blue
  blue_try[ , 1] = blue_try[ , 1] %% row + 1L
  blue_try
}

##################################################################### calculate the next position of red cars
next_red_car = function(Red, column){
  red_try = Red
  red_try[ , 2] = red_try[ , 2] %% column + 1L
  red_try
}

#################################################### up function for blue cars
up = function(g, bl, bl_next){
  g[bl] = "white"
  bl = bl_next
  g[bl] = "blue"
  #class(g)
  g
}

#################################################### right function for red cars
right = function(g, rd, rd_next){
  g[rd] = "white"
  rd = rd_next
  g[rd] = "red"
  #class(g)
  g
}

######################################counter for the movement of red and blue cars
car_info = function(moving)
{
  ctr = 0
  ctr = ctr + moving
  ctr
}

###############################updated version with car_info
move_blue_car = function(g, row, column){
  blue = position_current(g, 1)
  blue_next = next_blue_car(blue, row)
  blue_select = matrix(blue[g[blue_next] == "white"], ncol=2)### select the unblocked blue cars
  next_blue_select = next_blue_car(blue_select, row)
  g = up(g, blue_select, next_blue_select)### move only the unblocked blue cars
  info_b = car_info(length(blue_select[,1]))
  status_b <<- c(status_b, info_b)
  #plot(g, row, column)
  return(g)
}

#########################################updated version with car info
move_red_car = function(g, row, column){
  red = position_current(g, 2)
  red_next = next_red_car(red, column)
  red_select = matrix(red[g[red_next] == "white"], ncol=2)### select the unblocked blue cars
  next_red_select = next_red_car(red_select, column)
  g = right(g, red_select, next_red_select)### move only the unblocked blue cars
  info_r = car_info(length(red_select[,1]))
  status_r <<- c(status_r, info_r)
  #plot(g, row, column)
  return(g)
}

move_cars = function(g, row, column){
  g = move_blue_car(g, row, column)
  g = move_red_car(g, row, column)
  g
}

################################ simulate the BML taffic
traffic = function(g, row, column, n){
  #browser()
  for(t in 1 : (n/2)){
    g = move_cars(g, row, column)
  }
  g
}

################################calculate velocity
velocity = function(status, n){
 (sum(status)/n) 
}

################################summary about moving and blocking status and car velocity
Summary = function(status_b, status_r, n){

 status = cbind(status_b, status_r)

colnames(status) = c("moved_b", "moved_r")
total_v = velocity((status_r + status_b), n)
red_v = velocity(status_r, n)
blue_v = velocity(status_b, n)
list(TrafficStatus = status, TotalVelocity = total_v, RedCarV = red_v, BlueCarV = blue_v)
}

runBMLGrid = function(g, row, column, numSteps){
# plot(g, row, column)
  g = traffic(g, row, column, numSteps)
  Summary(status_b, status_r, numSteps)
  list(GridStatus = g, SUM = Summary(status_b, status_r, numSteps))
}
# Grid = createBMLGrid(6,6,7,7)
# runBMLGrid(Grid[[1]], 6, 6,10)
# runBMLGrid(grid, 6, 5, 10)
summary.BML = function(g){
  BMLgrid = g
  ans = table(g)
  class(ans) = "summary.BML"
  ans
}
#summary(grid)
################################################interaction with c

#library(BML)
move_color_c = function(g, car_type, roc, G)
  #   car_type is an number, corresponding the color of car in the grid
  #   red : car_type = 2
  #   blue : car_type = 1
  #   roc is an number, corresponding row or column
  #   row for red: roc = 1
  #   column for blue: roc = 2
{
  ROC = c(G[[3]], G[[4]])
  out = .C("move_cars", as.integer(g), as.integer(length(as.integer(g))), as.integer(car_type), as.integer(ROC[roc]), position = integer(G[[5]]))
  g = matrix(out[[1]], nrow = ROC[roc])
  positions = setdiff(out$position, 0) - 1
  list(g, positions)
}
 #move_color_c(grid, 1, 1, Grid)
move_red_c = function(g, G){
  # return the bml grid and the number of red car moved
  #status_r = NULL
  oo = move_color_c(g, 2, 1, G)
  g = oo[[1]]
  #status_r$row = oo[[2]] %% Grid[[3]] + 1
  #status_r$column = oo[[2]] %/% Grid[[3]] +1
  count_r = length(oo[[2]])
  class(g) = c("BML", "matrix")
  #plot(g)
  list(g, count_r)
}

move_blue_c = function(g, G){
  #status_b = NULL
  oo = move_color_c(t(g)[, nrow(g):1], 1, 2, G)
  g = oo[[1]]
  g = t(g)[ncol(g):1, ]# move blue
  #status_b$row = oo[[2]] %% Grid[[3]] + 1
  #status_b$column = oo[[2]] %/% Grid[[3]] +1
  count_b = length(oo[[2]])
  class(g) = c("BML", "matrix")
  #plot(g)
  list(g, count_b)
}

move_car_c = function(g, G){
  out_r = move_red_c(g, G)
  g = out_r[[1]]
  out_b = move_blue_c(g, G)
  g = out_b[[1]]
  list(g, out_r[[2]], out_b[[2]])
}

crunBMLGrid = function(g, G, numsteps){
  out_r = NULL
  out_b = NULL
  for(i in 1 : numsteps/2){
    results = move_car_c(g, G)
    g = results[[1]]
    out_r = c(out_r, results[[2]])
    out_b = c(out_b, results[[3]])
    #plot(g)
  }
  list(g, out_r, out_b)
}
